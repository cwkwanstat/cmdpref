#' sample data for non-metric mdpref
#'
#' @name mydata
#' @docType data
#' @keywords data
NULL
